package be.odisee.brainstorm;

public interface Application {}
