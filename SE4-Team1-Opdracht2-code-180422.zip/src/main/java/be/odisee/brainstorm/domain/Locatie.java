

package be.odisee.brainstorm.domain;

import java.util.List;

/**
 * @author aikod
 * @version 1.0
 * @created 25-Mar-2018 23:18:14
 */
public class Locatie {

	private String adres;
	private int id;
	private List<Product> producten;
	private String status;



	public void finalize() throws Throwable {

	}

	public Locatie(){

	}

}