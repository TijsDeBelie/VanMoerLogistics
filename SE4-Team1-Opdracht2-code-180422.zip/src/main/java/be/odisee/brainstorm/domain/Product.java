
package be.odisee.brainstorm.domain;

/**
 * @author aikod
 * @version 1.0
 * @created 25-Mar-2018 23:18:17
 */
public class Product {

	private int aantal;
	private String code;
	private int id;
	private String naam;
	private Locatie m_Locatie;



	public void finalize() throws Throwable {

	}

	public Product(){

	}

}