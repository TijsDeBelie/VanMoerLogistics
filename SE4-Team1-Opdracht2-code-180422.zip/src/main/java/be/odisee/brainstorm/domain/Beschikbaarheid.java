
package be.odisee.brainstorm.domain;

/**
 * @author aikod
 * @version 1.0
 * @created 25-Mar-2018 23:17:55
 */
public class Beschikbaarheid {

	private Chauffeur chauffeur;
	private int id;
	private String status;
	private int uurVanDeDag;
	private Planning m_Planning;



	public void finalize() throws Throwable {

	}

	public Beschikbaarheid(){

	}

}