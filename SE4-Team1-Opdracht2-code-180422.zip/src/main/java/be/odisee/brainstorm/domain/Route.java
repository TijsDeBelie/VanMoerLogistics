
package be.odisee.brainstorm.domain;

/**
 * @author aikod
 * @version 1.0
 * @created 25-Mar-2018 23:18:20
 */
public class Route {

	private Locatie bestemming;
	private int id;
	private String status;
	private Locatie vertrekpunt;



	public void finalize() throws Throwable {

	}

	public Route(){

	}

}